import './_closest.polyfill.js';
import './_customEvent.polyfill.js';
import './_requestAnimationFrame.polyfill.js';
import SmoothScroll from './core.js';

export default SmoothScroll;